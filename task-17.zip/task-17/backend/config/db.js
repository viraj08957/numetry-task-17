import mongoose from "mongoose";

const connectDatabase = async () => {
  try {
    const connectingDb = await mongoose.connect(
      "mongodb://0.0.0.0:27017/booking"
    );
    console.log(`MongoDb Connected on ${connectingDb.connection.host}`);
  } catch (err) {
    console.log(`Error : ${err.message}`);
    process.exit(1);
  }
};

export default connectDatabase;
